<!DOCTYPE html>
<html lang="en">
<head>

    <title>Daftar Mahasiswa</title>

</head>
<body>
    <h2>Daftar Mahasiswa</h2>
    <table border="1" cellpadding="5" cellspacing="0">
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>NIM</th>
            <th>Jurusan</th>
        </tr>
        <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($mhs->id); ?></td>
            <td><?php echo e($mhs->nama); ?></td>
            <td><?php echo e($mhs->nim); ?></td>
            <td><?php echo e($mhs->jurusan); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    
</body>
</html><?php /**PATH /Users/sandy/Documents/SEMESTER 3/PABW-semester3/praktikum4/resources/views/mahasiswa.blade.php ENDPATH**/ ?>