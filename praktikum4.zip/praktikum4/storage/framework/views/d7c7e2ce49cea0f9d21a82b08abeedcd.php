<!DOCTYPE html>
<html lang="en">
<head>
    <title>From Input Mahasiswa</title>
</head>
<body>
    <h2>Input Data Mahasiswa</h2>
    <form action="/simpan" method="POST">
        <?php echo csrf_field(); ?>
        <label>Nama:</label><br>
        <input type="text" name="nama"><br><br>
    
        <label>Email: </label><br>
    <input type="email" name="email"><br><br>
        
        <label>Jurusan</label><br>
        <input type="text" name="jurusan"><br><br>

        <label>Umur: </label><br>
    <input type="number" name="umur"><br><br>
    
        <button type="submit">Simpan</button>
    
    </form>
</body>
</html><?php /**PATH /Users/sandy/Documents/SEMESTER 3/PABW-semester3/praktikum4/resources/views/form.blade.php ENDPATH**/ ?>